# Bioinformatics and Biological Modeling Scripts

This repository is a collection of standalone Python examples for exploring biological systems with numerical models, stochastic simulations, and basic statistical analysis. The scripts use synthetic or hard-coded inputs and run independently. Each one saves a figure next to the script, displays it, or prints a statistical result. There is no shared application entry point or command-line configuration.

## What is included

Scripts are grouped by topic. Each folder contains the scripts and the figures they produce.

### `gene_regulation_models/`

| Script | Description | Result |
| --- | --- | --- |
| `gene_activation_hill.py` | ODE model of an activating Hill-function gene interaction | Plot of two gene abundances over time |
| `gene_repression_hill.py` | ODE model of gene expression with Hill-function repression | Plot of two gene abundances over time |
| `mrna_protein_model.py` | Deterministic mRNA and protein production/degradation model | Plot of mRNA and protein abundance |
| `repressilator_ode.py` | Three-gene deterministic regulatory network with activating and repressing Hill functions | Three-panel abundance plot |

### `stochastic_simulation/`

| Script | Description | Result |
| --- | --- | --- |
| `gillespie_mrna_birth_death.py` | Stochastic single-species production and degradation simulation | Plot of molecule count over time |
| `gillespie_logistic_growth.py` | Stochastic birth-death population model with density-dependent loss | Plot of population size over time |
| `gillespie_repressilator.py` | Stochastic three-gene regulatory network simulation | Three-panel gene-count plot |

### `population_models/`

| Script | Description | Result |
| --- | --- | --- |
| `logistic_growth_ode.py` | Deterministic logistic population growth model | Plot of population size over time |
| `predator_prey_lotka_volterra.py` | Lotka-Volterra-style predator-prey ODE model | Separate plots of fish and bear populations |

### `statistics/`

| Script | Description | Result |
| --- | --- | --- |
| `one_way_anova.py` | One-way ANOVA on three generated sample groups, followed by Tukey HSD post-hoc comparisons | F-statistic, p-value, significance message and pairwise comparisons |
| `anova_small_groups.py` | One-way ANOVA on three small, hard-coded sample groups | F-statistic and p-value |
| `volcano_plot.py` | Volcano plot generated from simulated fold changes and p-values | Scatter plot classifying points as up, down, or not significant |

The statistical scripts use example data, not measurements from a real experiment. `anova_small_groups.py` was previously named `t-test.py`; it runs a one-way ANOVA (`scipy.stats.f_oneway`), not a t-test.

### `single_cell_analysis/`

| Notebook | Description | Result |
| --- | --- | --- |
| `nk_cytotoxic_programme_pbmc3k.ipynb` | Scanpy workflow on public PBMC single-cell data, with a cytotoxic gene panel and NK vs CD8 T differential expression. Needs its own requirements (see the folder README) and an internet connection for the first run. | UMAP, dot plots, gene-expression table and volcano plot |

## Requirements

- Python 3
- Packages listed in [`requirements.txt`](requirements.txt): NumPy, SciPy (1.8 or later, for `tukey_hsd`), Matplotlib, pandas, and seaborn
- No special plotting setup is needed. Each plotting script saves a PNG next to the script and then calls `plt.show()`, which opens a window if a display is available.

## Setup

From the project directory, create and activate a virtual environment, then install the dependencies.

### Windows (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

If PowerShell prevents virtual-environment activation, either adjust the execution policy for your user according to your organization's guidance, or run the environment's Python directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### macOS or Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Usage

Run any script from the project directory with the environment activated:

```bash
python gene_regulation_models/repressilator_ode.py
python population_models/logistic_growth_ode.py
python statistics/volcano_plot.py
```

On macOS or Linux, use `python3` if that is how Python is installed.

The modeling and plotting examples save their figure as a PNG next to the script and open a Matplotlib window; close the window to finish the script. To run without opening windows (for example on a server), set `MPLBACKEND=Agg` first. The ANOVA examples print their output in the terminal:

```bash
python statistics/one_way_anova.py
python statistics/anova_small_groups.py
```

Most parameters, initial conditions, and time ranges are defined near the top of each file and can be edited directly. The Gillespie scripts use fixed random seeds so results are reproducible; change the seeds to see other realisations. The scripts do not accept command-line arguments or load external datasets.

## Contributing

Contributions that improve the examples while keeping them approachable are welcome:

1. Open an issue describing a bug, proposed improvement, or new example before making a substantial change.
2. Make a focused change in a separate branch and keep each script independently runnable.
3. Keep dependencies declared in `requirements.txt`; include clear units, assumptions, and parameter descriptions where useful.
4. Run the changed script after installing the requirements. For plotting scripts, verify that the figure is produced; for statistical scripts, verify that the printed output is sensible.
5. Submit a pull request describing the change and how it was checked. Include sample output or a figure when it helps explain the change.

There is no automated test suite or formatting configuration in the repository at present.

## License

No license file is currently included. Please contact the project maintainer before reusing the code.
