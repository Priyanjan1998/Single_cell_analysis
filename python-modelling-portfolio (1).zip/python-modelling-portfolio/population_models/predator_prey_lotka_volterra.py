"""Lotka-Volterra predator-prey model (fish and bears) solved with odeint."""
from pathlib import Path
from scipy.integrate import odeint
import matplotlib.pyplot as plt
import numpy as np

y0 = [10, 1]  # [fish, bears] units in hundreds
t = np.linspace(0, 50, num=1000)

alpha = 1.1
beta = 0.4
delta = 0.1
gamma = 0.4

params = [alpha, beta, delta, gamma]


def sim(variables, t, params):

    # fish population level
    x = variables[0]

    # bear population level
    y = variables[1]

    alpha = params[0]
    beta = params[1]
    delta = params[2]
    gamma = params[3]

    dxdt = alpha * x - beta * x * y
    dydt = delta * x * y - gamma * y

    return ([dxdt, dydt])


y = odeint(sim, y0, t, args=(params,))

f, (ax1, ax2) = plt.subplots(2)

line1, = ax1.plot(t, y[:, 0], color="b")
line2, = ax2.plot(t, y[:, 1], color="r")

ax1.set_ylabel("Fish (hundreds)")
ax2.set_ylabel("Bears (hundreds)")
ax2.set_xlabel("Time")

plt.savefig(Path(__file__).with_name("predator_prey_lotka_volterra.png"), dpi=150, bbox_inches="tight")
plt.show()
