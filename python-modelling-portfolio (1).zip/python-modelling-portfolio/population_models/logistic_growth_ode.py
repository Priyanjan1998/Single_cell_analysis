"""Logistic growth of a cell population, dX/dt = rX(1 - X/K), solved with odeint."""
from pathlib import Path
from scipy.integrate import odeint
import numpy as np
import matplotlib.pyplot as plt

# Initial conditions
y0 = [1]  # start with 1 cell

# Time points
t = np.linspace(0, 500, num=1000)

# Parameters (Note the uppercase K)
r = 0.05
K = 100000

params = [r, K]

# System of differential equations


def sim(variables, t, params):
    X = variables[0]

    r = params[0]
    K = params[1]

    dXdt = r * X * (1 - X / K)
    return [dXdt]


# Integrate ODE
y = odeint(sim, y0, t, args=(params,))

# Plot results
plt.plot(t, y[:, 0])
plt.xlabel("Time")
plt.ylabel("Cells")
plt.savefig(Path(__file__).with_name("logistic_growth_ode.png"), dpi=150, bbox_inches="tight")
plt.show()
