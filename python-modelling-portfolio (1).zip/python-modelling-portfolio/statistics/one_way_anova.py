"""One-way ANOVA on simulated control and two drug-treated groups (n = 30 each), followed by Tukey HSD post-hoc comparisons."""
import numpy as np
import pandas as pd
import scipy.stats as stats


np.random.seed(42)


control = np.random.normal(loc=10.2, scale=1.5, size=30)
treated_drugA = np.random.normal(loc=10.5, scale=1.2, size=30)
treated_drugB = np.random.normal(loc=14.1, scale=1.6, size=30)


f_stat, p_val = stats.f_oneway(control, treated_drugA, treated_drugB)

# 3. PRINT RESULTS
print(f"F-Statistic: {f_stat:.4f}")
print(f"P-value:     {p_val:.4e}")

if p_val < 0.05:
    print("\nResult: Statistically significant! At least one group differs.")
else:
    print("\nResult: Not significant. No statistical difference between groups.")

# Post-hoc: which groups differ? (Tukey HSD, scipy >= 1.8)
tukey = stats.tukey_hsd(control, treated_drugA, treated_drugB)
print("\nTukey HSD (0 = control, 1 = drug A, 2 = drug B):")
print(tukey)
